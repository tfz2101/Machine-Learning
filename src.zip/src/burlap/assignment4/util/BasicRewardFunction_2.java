package burlap.assignment4.util;

import burlap.assignment4.BasicGridWorld;
import burlap.assignment4.EasyGridWorldLauncher;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.RewardFunction;

public class BasicRewardFunction_2 implements RewardFunction {

	int goalX;
	int goalY;

	public BasicRewardFunction_2(int goalX, int goalY) {
		this.goalX = goalX;
		this.goalY = goalY;
	}

	@Override

	public double reward(State s, GroundedAction a, State sprime) {

		// get location of agent in next state
		ObjectInstance agent = sprime.getFirstObjectOfClass(BasicGridWorld.CLASSAGENT);
		int ax = agent.getIntValForAttribute(BasicGridWorld.ATTX);
		int ay = agent.getIntValForAttribute(BasicGridWorld.ATTY);

		// are they at goal location?
		if (ax == this.goalX && ay == this.goalY) {
			return 100.;
		}

		return -1;
	}

	public double reward_Easy(State s, GroundedAction a, State sprime) {
		int[][] rewardMap = new int[][] { 
			{ 96, 95, 94},
			{ 97, 94, 89},
			{ 98, 92, 90},};
		// get location of agent in next state
		ObjectInstance agent_s = s.getFirstObjectOfClass(BasicGridWorld.CLASSAGENT);
		int x = agent_s.getIntValForAttribute(BasicGridWorld.ATTX);
		int y = agent_s.getIntValForAttribute(BasicGridWorld.ATTY);
		
		// get location of agent in next state
		ObjectInstance agent = sprime.getFirstObjectOfClass(BasicGridWorld.CLASSAGENT);
		int ax = agent.getIntValForAttribute(BasicGridWorld.ATTX);
		int ay = agent.getIntValForAttribute(BasicGridWorld.ATTY);

		double r = (EasyGridWorldLauncher.amtMap[ax][ay] - EasyGridWorldLauncher.amtMap[x][y])*(rewardMap[ax][ay]);
		return r;
	}

	
	
}
