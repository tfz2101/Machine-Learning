package burlap.assignment4.util;

import burlap.assignment4.BasicGridWorld;
import burlap.behavior.policy.Policy.GroundedAnnotatedAction;
import burlap.behavior.policy.Policy.PolicyUndefinedException;
import burlap.behavior.singleagent.options.Option;
import burlap.oomdp.core.AbstractGroundedAction;
import burlap.oomdp.core.Domain;
import burlap.oomdp.core.TerminalFunction;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.RewardFunction;
import burlap.oomdp.singleagent.environment.SimulatedEnvironment;
import burlap.oomdp.singleagent.explorer.TerminalExplorer;
import burlap.tutorials.bd.ExampleGridWorld;

public class Test {
	private static Integer MAX_ITERATIONS = 100;
	private static Integer NUM_INTERVALS = 100;

	protected static int[][] userMap = new int[][] { 
			{ 0, 0, 0},
			{ 0, 0, 0},
			{ 0, 0, 0},};
	
	
	public static int[][] amtMap = new int[][] { 
				{ 50, 25, 0},
				{ 70, 60, 30},
				{ 100, 80, 50},};
	
	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// convert to BURLAP indexing
		int[][] map = MapPrinter.mapToMatrix(userMap);
		int maxX = map.length-1;
		int maxY = map[0].length-1;
		
		BasicGridWorld gen = new BasicGridWorld(map,maxX,maxY); //0 index map is 11X11
		Domain domain = gen.generateDomain();

		State initialState = BasicGridWorld.getExampleState(domain);

	

	}

}




/*
//follow policy
AbstractGroundedAction aga = this.getAction(cur);


GroundedAction ga = (GroundedAction)aga;

*/
