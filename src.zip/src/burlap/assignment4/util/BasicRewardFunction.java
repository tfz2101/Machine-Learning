package burlap.assignment4.util;

import burlap.assignment4.BasicGridWorld;
import burlap.assignment4.EasyGridWorldLauncher;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.singleagent.GroundedAction;
import burlap.oomdp.singleagent.RewardFunction;

public class BasicRewardFunction implements RewardFunction {

	int rewardMap[][];
	int amtMap[][];
	int goalX, goalY;
	public BasicRewardFunction(int rewardMap[][], int amtMap[][]) {
		this.rewardMap = rewardMap;
		this.amtMap = amtMap;
	}

	public BasicRewardFunction(int maxX, int maxY) {
		this.goalX = maxX;
		this.goalY = maxY;
	}

	@Override

	public double reward(State s, GroundedAction a, State sprime) {
		int farX = amtMap.length -1;
		int farY = amtMap[0].length -1;
		
		// get location of agent in next state
		ObjectInstance agent_s = s.getFirstObjectOfClass(BasicGridWorld.CLASSAGENT);
		int x_a = agent_s.getIntValForAttribute(BasicGridWorld.ATTX);
		int y_a = agent_s.getIntValForAttribute(BasicGridWorld.ATTY);
		
		// get location of agent in next state
		ObjectInstance agent = sprime.getFirstObjectOfClass(BasicGridWorld.CLASSAGENT);
		int ax_a = agent.getIntValForAttribute(BasicGridWorld.ATTX);
		int ay_a = agent.getIntValForAttribute(BasicGridWorld.ATTY);
		System.out.println(x_a+","+y_a+" to "+ax_a+","+ay_a);
		
		int x = farX - y_a;
		int y = x_a;
		
		int ax = farX - ay_a;
		int ay = ax_a;
		System.out.println( farX+","+farY);
		System.out.println(x+","+y+" to "+ax+","+ay);
		//System.out.println(amtMap[x][y]);
		//System.out.println(amtMap[ax][ay]);
		//System.out.println(rewardMap[ax][ay]);
		double r = (amtMap[x][y] - amtMap[ax][ay])*(rewardMap[ax][ay]);
		
		//System.out.println(EasyGridWorldLauncher.amtMap.length+","+EasyGridWorldLauncher.amtMap[0].length);
		//System.out.println(r);
		return r;
	}

/*
	public double reward(State s, GroundedAction a, State sprime) {

		// get location of agent in next state
		ObjectInstance agent = sprime.getFirstObjectOfClass(BasicGridWorld.CLASSAGENT);
		int ax = agent.getIntValForAttribute(BasicGridWorld.ATTX);
		int ay = agent.getIntValForAttribute(BasicGridWorld.ATTY);

		// are they at goal location?
		if (ax == this.goalX && ay == this.goalY) {
			return 100.;
		}

		return -1;
	}
*/
}
