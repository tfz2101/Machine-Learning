package burlap.testing;

import org.junit.Assert;
import org.junit.Test;

public class TestTesting {

		@Test
		public void testAddition() {
			Assert.assertEquals(4, 2 + 2);
		}
}
